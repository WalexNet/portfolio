"""Conversor de bases numéricas."""
