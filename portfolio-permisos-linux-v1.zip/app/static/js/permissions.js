document.addEventListener("DOMContentLoaded", () => {
  const boxes = [...document.querySelectorAll(".permissions-check input")];
  const octalField = document.getElementById("permissions-octal");
  const symbolicField = document.getElementById("permissions-symbolic");
  const octalOutput = document.getElementById("permissions-octal-output");
  const symbolicOutput = document.getElementById("permissions-symbolic-output");
  const targetField = document.getElementById("permissions-target");
  const commandOutput = document.getElementById("permissions-command-output");
  const error = document.getElementById("permissions-error");
  const copyStatus = document.getElementById("permissions-copy-status");
  let currentOctal = "754";

  function parseOctal(value) {
    if (!/^[0-7]{3}$/.test(value)) return null;
    return [...value].flatMap(digit => {
      const value = Number(digit);
      return [!!(value & 4), !!(value & 2), !!(value & 1)];
    });
  }

  function parseSymbolic(value) {
    if (!/^[r-][w-][x-][r-][w-][x-][r-][w-][x-]$/.test(value)) return null;
    return [...value].map(character => character !== "-");
  }

  function fromBoxes() { return boxes.map(box => box.checked); }

  function render(bits) {
    boxes.forEach((box, index) => { box.checked = bits[index]; });
    const digits = [0, 3, 6].map(i =>
      String((bits[i] ? 4 : 0) + (bits[i+1] ? 2 : 0) + (bits[i+2] ? 1 : 0))
    );
    currentOctal = digits.join("");
    const symbolic = bits.map((yes, i) => yes ? "rwx"[i % 3] : "-").join("");
    octalField.value = currentOctal;
    symbolicField.value = symbolic;
    octalOutput.textContent = currentOctal;
    symbolicOutput.textContent = symbolic;
    error.hidden = true;
    error.textContent = "";
    updateCommand();
  }

  function shellQuote(input) {
    // A single-quoted POSIX shell argument, even for names with apostrophes.
    return "'" + input.replace(/'/g, "'\\''") + "'";
  }

  function updateCommand() {
    const name = targetField.value.trim();
    commandOutput.textContent = "chmod " + currentOctal +
      (name ? " -- " + shellQuote(name) : " -- 'archivo.txt'");
    copyStatus.textContent = "";
  }

  function invalid(message) { error.textContent = message; error.hidden = false; }

  boxes.forEach(box => box.addEventListener("change", () => render(fromBoxes())));
  octalField.addEventListener("input", () => {
    const parsed = parseOctal(octalField.value.trim());
    if (parsed) render(parsed);
    else invalid("Escribe exactamente tres cifras octales, de 0 a 7.");
  });
  symbolicField.addEventListener("input", () => {
    const parsed = parseSymbolic(symbolicField.value.trim());
    if (parsed) render(parsed);
    else invalid("Escribe nueve caracteres, por ejemplo rwxr-xr-x.");
  });
  targetField.addEventListener("input", updateCommand);
  document.querySelectorAll("[data-mode]").forEach(button =>
    button.addEventListener("click", () => render(parseOctal(button.dataset.mode)))
  );
  document.getElementById("permissions-copy").addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(commandOutput.textContent);
      copyStatus.textContent = "Comando copiado.";
    } catch {
      copyStatus.textContent = "No se pudo copiar. Selecciona el comando manualmente.";
    }
  });
  render(parseOctal("754"));
});
